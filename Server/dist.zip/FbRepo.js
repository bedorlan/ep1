"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("isomorphic-fetch");
const fbUrl = 'https://graph.facebook.com/v6.0/';
const accessToken = '591967211411620%7C5SIbfmYv4ry7RF6E905sSnVunXc';
async function getNamesFor(ids) {
    const idsParam = ids.join(',');
    const url = `${fbUrl}/?ids=${idsParam}&fields=short_name&${getAcessTokenParam()}`;
    const response = await fetch(url);
    return await response.json();
}
exports.getNamesFor = getNamesFor;
async function getFriendsOf(fbId) {
    const url = `${fbUrl}/${fbId}/friends?fields=short_name&${getAcessTokenParam()}`;
    const response = await fetch(url);
    // todo: check paging
    const { data, paging } = await response.json();
    return data;
}
exports.getFriendsOf = getFriendsOf;
async function debugToken(token) {
    const url = `${fbUrl}/debug_token?input_token=${token}&${getAcessTokenParam()}`;
    const response = await fetch(url);
    const data = await response.json();
    return data.data;
}
exports.debugToken = debugToken;
function getAcessTokenParam() {
    return `access_token=${accessToken}`;
}
