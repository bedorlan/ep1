"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const crypto = require("crypto");
const lodash = require("lodash");
const net = require("net");
const stream_1 = require("stream");
const Attestation = require("./Attestation");
const FbRepo = require("./FbRepo");
const ScoresRepo = require("./ScoresRepo");
const Elo_1 = require("./Elo");
const Telepathy_1 = require("./Telepathy");
const DecryptRsa_1 = require("./DecryptRsa");
var Codes;
(function (Codes) {
    Codes[Codes["noop"] = 0] = "noop";
    Codes[Codes["start"] = 1] = "start";
    Codes[Codes["newPlayerDestination"] = 2] = "newPlayerDestination";
    Codes[Codes["newVoters"] = 3] = "newVoters";
    Codes[Codes["guessTime"] = 5] = "guessTime";
    Codes[Codes["projectileFired"] = 6] = "projectileFired";
    Codes[Codes["tryConvertVoter"] = 7] = "tryConvertVoter";
    Codes[Codes["voterConverted"] = 8] = "voterConverted";
    Codes[Codes["tryClaimVoter"] = 9] = "tryClaimVoter";
    Codes[Codes["voterClaimed"] = 10] = "voterClaimed";
    Codes[Codes["hello"] = 11] = "hello";
    Codes[Codes["tryAddVotes"] = 12] = "tryAddVotes";
    Codes[Codes["votesAdded"] = 13] = "votesAdded";
    Codes[Codes["log"] = 14] = "log";
    Codes[Codes["newAlly"] = 15] = "newAlly";
    Codes[Codes["destroyProjectile"] = 16] = "destroyProjectile";
    Codes[Codes["introduce"] = 17] = "introduce";
    Codes[Codes["matchOver"] = 18] = "matchOver";
    Codes[Codes["newScores"] = 19] = "newScores";
    Codes[Codes["joinAllQueue"] = 20] = "joinAllQueue";
    Codes[Codes["joinFriendsQueue"] = 21] = "joinFriendsQueue";
    Codes[Codes["getLeaderboardAll"] = 22] = "getLeaderboardAll";
    Codes[Codes["leaderboardAll"] = 24] = "leaderboardAll";
    Codes[Codes["attestation"] = 25] = "attestation";
    Codes[Codes["attested"] = 26] = "attested";
    Codes[Codes["version"] = 27] = "version";
    Codes[Codes["versionOutdated"] = 28] = "versionOutdated";
})(Codes || (Codes = {}));
const MAP_WIDTH = 190;
const MATCH_TIME = Number.parseFloat(process.env.MATCH_TIME || '4') * 60 * 1000;
const server = net.createServer();
let waitingQueue = [];
let matchesRunning = 0;
setInterval(tryStartMatch, Number.parseFloat(process.env.LOBBY_WAIT_TIME || '60') * 1000);
server.on('connection', async (socket) => {
    let aesKey;
    try {
        await safeWaitForHello(socket);
        aesKey = await safeWaitForKey(socket);
    }
    catch (err) {
        console.info(err);
        socket.destroy();
        return;
    }
    const duplex = {
        socket,
        in: new stream_1.PassThrough({ objectMode: true }),
        out: new stream_1.PassThrough({ objectMode: true }),
        nonce: Attestation.getNonce(),
        attested: false,
    };
    let aesIv = Buffer.from(duplex.nonce.slice(0, 16), 'utf-8');
    stream_1.pipeline(socket, new Telepathy_1.TelepathyInputTransformer(), new stream_1.Transform({
        objectMode: true,
        transform(obj, encoding, cb) {
            try {
                const decipher = crypto.createDecipheriv('aes-128-cbc', aesKey, aesIv);
                const result = Buffer.concat([decipher.update(obj), decipher.final()]);
                aesIv = Buffer.concat([result, Buffer.from('................')], 16);
                cb(null, result);
            }
            catch (err) {
                cb(err);
            }
        },
    }), new stream_1.Transform({
        objectMode: true,
        transform(obj, encoding, cb) {
            let msg;
            try {
                msg = JSON.parse(obj);
            }
            catch (err) {
                console.info(err + '\nmsg=' + obj.toString());
                return cb();
            }
            if (tryHandleMsg(duplex, msg))
                cb();
            else
                cb(null, msg);
        },
    }), duplex.in, socketClosed.bind(null, duplex));
    stream_1.pipeline(duplex.out, new stream_1.Transform({
        objectMode: true,
        transform(obj, encoding, cb) {
            if (!process.env.LATENCY)
                cb(null, obj);
            else
                setTimeout(() => cb(null, obj), Number.parseInt(process.env.LATENCY));
        },
    }), new stream_1.Transform({
        writableObjectMode: true,
        readableObjectMode: false,
        transform(obj, encoding, cb) {
            const msg = Telepathy_1.toTelepathyMsg(JSON.stringify(obj));
            cb(null, msg);
        },
    }), socket, socketClosed.bind(null, duplex));
    sendTo(duplex, [Codes.hello, duplex.nonce]);
});
function safeWaitForHello(socket) {
    const BYTES_TO_READ = 4 + 4; // Codes.hello: 0004[11]
    return new Promise((resolve, reject) => {
        socket.on('readable', () => {
            if (socket.readableLength < BYTES_TO_READ)
                return;
            const data = socket.read(BYTES_TO_READ).toString();
            let code;
            try {
                ;
                [code] = JSON.parse(data.slice(4));
            }
            catch (err) {
                return reject(err + `\ndata=${data}`);
            }
            if (code !== Codes.hello)
                return reject('weird data: ' + data);
            socket.removeAllListeners();
            resolve();
        });
        socket.on('close', endSocket);
        socket.on('error', endSocket);
        function endSocket(err) {
            socket.removeAllListeners();
            reject(err);
        }
    });
}
function safeWaitForKey(socket) {
    const BYTES_TO_READ = 4 + 344;
    return new Promise((resolve, reject) => {
        socket.on('readable', () => {
            if (socket.readableLength < BYTES_TO_READ)
                return;
            try {
                const data = socket.read(BYTES_TO_READ).slice(4);
                const aesKey = DecryptRsa_1.decryptRsa(Buffer.from(data.toString('ascii'), 'base64'));
                socket.removeAllListeners();
                resolve(aesKey);
            }
            catch (err) {
                return reject(err);
            }
        });
        socket.on('close', endSocket);
        socket.on('error', endSocket);
        function endSocket(err) {
            socket.removeAllListeners();
            reject(err);
        }
    });
}
const generalCodesMap = {
    [Codes.guessTime]: onGuessTime,
    [Codes.log]: logReceived,
    [Codes.introduce]: onIntroduce,
    [Codes.joinAllQueue]: (player) => ((player.playWithFriends = false), waitingQueue.push(player), true),
    [Codes.joinFriendsQueue]: (player) => ((player.playWithFriends = true), waitingQueue.push(player), true),
    [Codes.getLeaderboardAll]: (player) => (sendFullLeaderboardToPlayer(player), true),
    [Codes.version]: checkVersion,
};
function tryHandleMsg(player, msg) {
    const code = msg[0];
    if (!player.attested) {
        if ([Codes.guessTime, Codes.log].includes(code)) {
            // pass
        }
        else if (code === Codes.attestation) {
            const jsonJwt = msg[1];
            Attestation.verifyJwt(player.nonce, jsonJwt).then((result) => {
                // todo: send a message to player explaining
                if (!result)
                    return player.socket.destroy();
                player.attested = true;
                sendTo(player, [Codes.attested]);
            });
            return true;
        }
        else
            return player.socket.destroy(new Error('weird message while attesting: ' + JSON.stringify(msg)));
    }
    if (!(code in generalCodesMap))
        return false;
    return generalCodesMap[code](player, msg);
}
function checkVersion(player, msg) {
    const [code, version] = msg;
    const numVersion = Number.parseFloat(version);
    if (numVersion < 505.2) {
        const msg = [Codes.versionOutdated];
        sendTo(player, msg);
        player.out.end();
    }
    return true;
}
function tryStartMatch() {
    clearDisconnectedPlayers();
    waitingQueue.sort((a, b) => { var _a, _b; return ((_a = a.score) !== null && _a !== void 0 ? _a : Elo_1.initialScore) - ((_b = b.score) !== null && _b !== void 0 ? _b : Elo_1.initialScore); });
    for (let matchCreated = true; matchCreated;) {
        const playingWithFriends = waitingQueue.filter((it) => it.playWithFriends);
        matchCreated = playingWithFriends.some((player) => {
            var _a;
            const myFriends = (_a = player.friends) === null || _a === void 0 ? void 0 : _a.map((it) => it.id);
            const myOnlineFriends = waitingQueue
                .filter((it) => it !== player)
                .filter((it) => it.fbId && (myFriends === null || myFriends === void 0 ? void 0 : myFriends.includes(it.fbId)));
            const newMatch = [player, ...myOnlineFriends].slice(0, 4);
            const playersPlaying = createMatches(newMatch);
            lodash.pull(waitingQueue, ...playersPlaying);
            return playersPlaying.length > 0;
        });
    }
    const playingWithAll = waitingQueue.filter((it) => !it.playWithFriends);
    const playersPlaying = createMatches(playingWithAll);
    lodash.pull(waitingQueue, ...playersPlaying);
}
function createMatches(players) {
    players = players.slice();
    const playersPlaying = [];
    while (players.length >= 2) {
        const matchSize = [5, 6].includes(players.length) ? 3 : 4;
        const matchPlayers = players.slice(0, matchSize);
        players = players.slice(matchSize);
        new Match(matchPlayers).Start();
        playersPlaying.push(...matchPlayers);
    }
    return playersPlaying;
}
function onGuessTime(player, msg) {
    const playerGuess = msg[1];
    const offset = Date.now() - playerGuess;
    sendTo(player, [Codes.guessTime, offset]);
    return true;
}
function onIntroduce(player, msg) {
    const [code, playerNumber, playerName, accessToken] = msg;
    if (accessToken) {
        FbRepo.debugToken(accessToken).then((data) => {
            if (!data.is_valid || !data.user_id)
                return;
            player.accessToken = accessToken;
            player.fbId = data.user_id;
            FbRepo.getNamesFor([player.fbId]).then((names) => { var _a; return (player.name = (_a = names[player.fbId]) === null || _a === void 0 ? void 0 : _a.short_name); });
            ScoresRepo.getScore(player.fbId).then((score) => (player.score = score === null || score === void 0 ? void 0 : score.score));
            FbRepo.getFriendsOf(player.fbId).then((friends) => (player.friends = friends));
        });
    }
    else {
        player.accessToken = undefined;
        player.fbId = undefined;
        player.name = undefined;
        player.score = undefined;
        player.friends = undefined;
    }
    return playerNumber === -1;
}
async function sendFullLeaderboardToPlayer(player) {
    if (!player.fbId)
        return;
    const leaderboards = await Promise.all([getTopLeaderboard(), getFriendsLeaderboard(player)]);
    const msg = [Codes.leaderboardAll, ...leaderboards];
    sendTo(player, msg);
}
async function getTopLeaderboard() {
    const top3 = await ScoresRepo.getTop3();
    const ids = top3.map((it) => it.fb_id);
    const names = await FbRepo.getNamesFor(ids);
    const leaderboard = top3
        .map((it) => ({
        name: names[it.fb_id].short_name,
        score: it.score,
    }))
        .sort((a, b) => b.score - a.score)
        .map((it) => [it.name, it.score]);
    // todo: include top 5?
    return leaderboard;
}
async function getFriendsLeaderboard(player) {
    var _a;
    if (!(player.fbId && player.friends))
        return [];
    const friends = player.friends.slice();
    const me = { id: player.fbId, short_name: (_a = player.name) !== null && _a !== void 0 ? _a : 'sin nombre' };
    friends.push(me);
    const ids = friends.map((it) => it.id);
    const scores = await ScoresRepo.batchGetScore(ids);
    const namesMap = Object.fromEntries(friends.map((it) => [it.id, it.short_name]));
    const response = scores.map((it) => [namesMap[it.fb_id], it.score]);
    response.sort((a, b) => b[1] - a[1]);
    return response;
}
function socketClosed(player, err) {
    if (player.inactive)
        return;
    if (err) {
        if (err.code !== 'ERR_STREAM_PREMATURE_CLOSE')
            console.info({ err });
        if (!player.socket.destroyed)
            player.socket.destroy();
    }
    clearDisconnectedPlayers();
}
function clearDisconnectedPlayers() {
    waitingQueue = waitingQueue.filter((it) => {
        const isGood = !it.socket.destroyed && it.socket.readable && it.socket.writable;
        if (isGood)
            return true;
        it.in.destroy();
        it.out.destroy();
        return false;
    });
}
function logReceived(player, msg) {
    console.info({ msg });
    return true;
}
const PORT = process.env.PORT ? Number.parseInt(process.env.PORT) : 7777;
server.on('listening', () => {
    console.info(`listening on port ${PORT}`);
});
server.on('error', (err) => {
    console.info('server error:', err);
});
server.listen(PORT);
class Match {
    constructor(players) {
        this.matchEnded = false;
        this.resendToOthers = (player, msg) => {
            this.players
                .filter((_, index) => index !== player)
                .forEach((other) => {
                sendTo(other, msg);
            });
        };
        this.StopPlayer = (playerNumber, err) => {
            const player = this.players[playerNumber];
            if (err) {
                if (err.code !== 'ERR_STREAM_PREMATURE_CLOSE')
                    console.info(err);
                player.in.destroy();
                player.out.destroy();
            }
            player.inactive = true;
            if (this.matchEnded)
                return;
            // todo: send to others that player disconnected perhaps?
            this.votersCentral.PunishPlayer(playerNumber);
            const playersPlaying = this.playersPlayingNumber();
            if (playersPlaying < 2)
                this.TryEndMatch();
        };
        this.TryEndMatch = async () => {
            const playersPlaying = this.playersPlayingNumber();
            const isThereAWinner = this.votersCentral.isThereAWinner();
            if (playersPlaying >= 2 && !isThereAWinner) {
                this.matchTimer = setTimeout(() => this.TryEndMatch(), 10000);
                return;
            }
            if (this.matchTimer) {
                clearTimeout(this.matchTimer);
                this.matchTimer = undefined;
            }
            this.matchEnded = true;
            this.votersCentral.Stop();
            this.resendToOthers(-1, [Codes.matchOver]);
            const newScores = await this.CalcEloScores();
            const scoresToSave = newScores
                .filter((it) => this.players[it.playerNumber].fbId)
                .map((it) => ({ fb_id: this.players[it.playerNumber].fbId, score: it.newScore }));
            await this.savePlayersScores(scoresToSave);
            const matchResult = newScores
                .slice()
                .sort((a, b) => a.playerNumber - b.playerNumber)
                .map((it) => [it.votes, it.newScore, it.scoreDiff]);
            const msg = [Codes.newScores, ...matchResult];
            this.resendToOthers(-1, msg);
            --matchesRunning;
            console.info('match ended', { matchesRunning });
        };
        this.players = players = lodash.shuffle(players);
        this.votersCentral = new VotersCentral(players);
    }
    Start() {
        const codesMap = {
            [Codes.newPlayerDestination]: this.resendToOthers,
            [Codes.projectileFired]: (player, msg) => {
                this.resendToOthers(player, msg);
                this.votersCentral.ProjectileFired(player, msg);
            },
            [Codes.tryConvertVoter]: this.votersCentral.TryConvertVoter,
            [Codes.tryClaimVoter]: this.votersCentral.TryClaimVoter,
            [Codes.tryAddVotes]: this.votersCentral.TryAddVotes,
            [Codes.newAlly]: this.resendToOthers,
            [Codes.destroyProjectile]: this.resendToOthers,
            [Codes.introduce]: (player, msg) => this.resendToOthers(player, msg.slice(0, 3)),
        };
        this.players.forEach((player, index) => {
            const stopPlayer = this.StopPlayer.bind(this, index);
            player.in.on('end', stopPlayer);
            player.in.on('close', stopPlayer);
            player.in.on('error', stopPlayer);
            player.in.on('data', (msg) => {
                if (this.matchEnded)
                    return;
                const code = msg[0];
                if (!(code in codesMap)) {
                    console.info('unmapped code', code);
                    return;
                }
                codesMap[code](index, msg);
            });
        });
        this.players.forEach((player, index) => {
            sendTo(player, [Codes.start, index, this.players.length]);
        });
        this.votersCentral.Start();
        this.matchTimer = setTimeout(this.TryEndMatch, MATCH_TIME);
        ++matchesRunning;
        console.info('new match:', { matchesRunning, players: this.players.map((it) => it.name) });
    }
    playersPlayingNumber() {
        return this.players.reduce((accum, next) => accum + (next.inactive ? 0 : 1), 0);
    }
    savePlayersScores(scores) {
        return Promise.all(scores.map((it) => {
            if (!it.fb_id)
                return;
            const score = { fb_id: it.fb_id, score: it.score };
            return ScoresRepo.putScore(score);
        }));
    }
    async CalcEloScores() {
        const results = this.votersCentral.getVotesResults();
        const playerPrevScores = this.players.map((it) => { var _a; return (_a = it.score) !== null && _a !== void 0 ? _a : Elo_1.initialScore; });
        const eloInputs = this.players.map((_, index) => ({
            id: index,
            prevScore: playerPrevScores[index],
            result: results[index],
        }));
        const newScores = Elo_1.multiElo(eloInputs);
        return newScores.map((it) => ({
            ...it,
            playerNumber: it.id,
            votes: results[it.id],
            scoreDiff: it.newScore - playerPrevScores[it.id],
        }));
    }
}
class VotersCentral {
    constructor(players) {
        this.players = players;
        this.matchEnded = false;
        this.voterSeq = 0;
        this.voters = [];
        this.PeriodicTasks = () => {
            if (this.matchEnded)
                return;
            this.SendVotersPack();
            this.SendVotersToCentrals();
        };
        this.SendVotersPack = () => {
            const votesPerSecond = Math.ceil(this.players.length / 2);
            const votersToSend = lodash.times(votesPerSecond).map(GenerateVoterPositionX).map(this.GenerateVoterCloseTo);
            this.SendVotersToAll(votersToSend);
        };
        this.SendVotersToCentrals = () => {
            this.centralBases.forEach((positionX, player) => {
                if (positionX === undefined)
                    return;
                if (Math.random() < 0.7)
                    return;
                var voter = this.GenerateVoterCloseTo(positionX);
                this.SendVoterConverted(player, voter);
            });
        };
        this.TryConvertVoter = (player, msg) => {
            const NO_PLAYER = -1;
            const [code, voterId, playerToConvertTo, time] = msg;
            const voter = this.voters[voterId];
            if (voter.claimed)
                return;
            if (playerToConvertTo !== NO_PLAYER && voter.lastHitTime > time)
                return;
            voter.player = playerToConvertTo;
            voter.lastHitTime = time;
            const reply = [Codes.voterConverted, voterId, playerToConvertTo];
            this.players.forEach((it) => {
                sendTo(it, reply);
            });
        };
        this.TryClaimVoter = (player, msg) => {
            const [code, voterId] = msg;
            const voter = this.voters[voterId];
            if (voter.claimed)
                return;
            if (voter.player !== player)
                return;
            voter.player = player;
            voter.claimed = true;
            ++this.votesCounts[player];
            const reply = [Codes.voterClaimed, voterId, player];
            this.players.forEach((it) => {
                sendTo(it, reply);
            });
        };
        this.TryAddVotes = (player, msg) => {
            const [code, playerNumberToAddVotes, votes] = msg;
            this.votesCounts[playerNumberToAddVotes] += votes;
            const reply = [Codes.votesAdded, playerNumberToAddVotes, votes];
            this.players.forEach((it) => {
                sendTo(it, reply);
            });
        };
        this.ProjectileFired = (player, msg) => {
            const CENTRAL_BASE_PROJECTILE_TYPES = [4, 5, 6];
            const ABSTENTION_PROJECTILE_TYPE = 13;
            const [code, playerOwner, destination, timeWhenReach, projectileType, targetPlayer, projectileId] = msg;
            const [projectilePositionX, projectilePositionY] = destination;
            if (CENTRAL_BASE_PROJECTILE_TYPES.includes(projectileType)) {
                this.centralBases[playerOwner] = projectilePositionX;
                lodash
                    .times(3)
                    .fill(projectilePositionX)
                    .map(this.GenerateVoterCloseTo)
                    .forEach(this.SendVoterConverted.bind(null, playerOwner));
                return;
            }
            if (projectileType === ABSTENTION_PROJECTILE_TYPE) {
                const generateVoters = () => {
                    if (this.matchEnded)
                        return;
                    this.SendVotersToAll(lodash.times(5).fill(projectilePositionX).map(this.GenerateVoterCloseTo));
                };
                generateVoters();
                generateVoters();
                setTimeout(generateVoters, 1000);
                setTimeout(generateVoters, 2000);
            }
        };
        this.SendVoterConverted = (playerOwner, voter) => {
            this.SendVotersToAll([voter]);
            this.TryConvertVoter(playerOwner, [Codes.tryConvertVoter, voter[0], playerOwner, Date.now()]);
        };
        this.GenerateVoterCloseTo = (x) => {
            let positionX = x + (Math.random() * 20.0 - 10.0);
            positionX = Math.min(positionX, MAP_WIDTH / 2);
            positionX = Math.max(positionX, MAP_WIDTH / -2);
            const voter = { positionX, lastHitTime: 0, player: -1, claimed: false };
            this.voters.push(voter);
            return [this.voterSeq++, positionX];
        };
        this.votesCounts = Array(players.length).fill(0);
        this.centralBases = Array(players.length).fill(undefined);
    }
    Start() {
        this.myInterval = setInterval(this.PeriodicTasks, 1000);
    }
    Stop() {
        this.matchEnded = true;
        if (this.myInterval)
            clearInterval(this.myInterval);
        this.myInterval = undefined;
    }
    SendVotersToAll(votersToSend) {
        const msg = [Codes.newVoters, ...votersToSend];
        this.players.forEach((player) => {
            sendTo(player, msg);
        });
    }
    PunishPlayer(playerNumber) {
        this.votesCounts[playerNumber] = 0;
    }
    isThereAWinner() {
        const sortedVotes = this.votesCounts.slice().sort((a, b) => b - a);
        return sortedVotes[0] > sortedVotes[1];
    }
    getVotesResults() {
        return Object.fromEntries(this.votesCounts.map((votes, index) => [index, votes]));
    }
}
function GenerateVoterPositionX() {
    const forVoterRegion = Math.random();
    const forVoterPosition = Math.random();
    let voterPosition;
    if (forVoterRegion < 0.26) {
        voterPosition = forVoterPosition * 0.18 + 0;
    }
    else if (forVoterRegion < 0.38) {
        voterPosition = forVoterPosition * 0.13 + 0.18;
    }
    else if (forVoterRegion < 0.78) {
        voterPosition = forVoterPosition * 0.3 + 0.31;
    }
    else if (forVoterRegion < 0.9) {
        voterPosition = forVoterPosition * 0.24 + 0.61;
    }
    else {
        voterPosition = forVoterPosition * 0.15 + 0.85;
    }
    return (voterPosition - 0.5) * MAP_WIDTH;
}
function sendTo(duplex, msg) {
    if (duplex.inactive)
        return;
    if (duplex.out.destroyed || !duplex.out.writable) {
        console.info('unable to send msg', msg);
        return;
    }
    duplex.out.write(msg);
}
