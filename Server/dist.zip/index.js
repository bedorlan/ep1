"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const lodash = require("lodash");
const net = require("net");
const stream_1 = require("stream");
const ScoresRepo = require("./ScoresRepo");
const Elo_1 = require("./Elo");
var Codes;
(function (Codes) {
    Codes[Codes["noop"] = 0] = "noop";
    Codes[Codes["start"] = 1] = "start";
    Codes[Codes["newPlayerDestination"] = 2] = "newPlayerDestination";
    Codes[Codes["newVoters"] = 3] = "newVoters";
    Codes[Codes["guessTime"] = 5] = "guessTime";
    Codes[Codes["projectileFired"] = 6] = "projectileFired";
    Codes[Codes["tryConvertVoter"] = 7] = "tryConvertVoter";
    Codes[Codes["voterConverted"] = 8] = "voterConverted";
    Codes[Codes["tryClaimVoter"] = 9] = "tryClaimVoter";
    Codes[Codes["voterClaimed"] = 10] = "voterClaimed";
    Codes[Codes["hello"] = 11] = "hello";
    Codes[Codes["tryAddVotes"] = 12] = "tryAddVotes";
    Codes[Codes["votesAdded"] = 13] = "votesAdded";
    Codes[Codes["log"] = 14] = "log";
    Codes[Codes["newAlly"] = 15] = "newAlly";
    Codes[Codes["destroyProjectile"] = 16] = "destroyProjectile";
    Codes[Codes["introduce"] = 17] = "introduce";
    Codes[Codes["matchOver"] = 18] = "matchOver";
    Codes[Codes["newScores"] = 19] = "newScores";
})(Codes || (Codes = {}));
const MAP_WIDTH = 190;
const MATCH_TIME = Number.parseFloat(process.env.MATCH_TIME || '4') * 60 * 1000;
const server = net.createServer();
let waitingQueue = [];
let matchesRunning = 0;
server.on('connection', async (socket) => {
    try {
        await safeWaitForHello(socket);
    }
    catch (err) {
        console.info(err);
        socket.destroy();
        return;
    }
    const duplex = {
        socket,
        in: new stream_1.PassThrough({ objectMode: true }),
        out: new stream_1.PassThrough({ objectMode: true }),
    };
    stream_1.pipeline(socket, new TelepathyInputTransformer(), new stream_1.Transform({
        objectMode: true,
        transform(obj, encoding, cb) {
            let msg;
            try {
                msg = JSON.parse(obj);
            }
            catch (err) {
                console.info(err + '\nmsg=' + obj.toString());
                return cb();
            }
            const code = msg[0];
            if (code === Codes.guessTime) {
                onGuessTime(duplex, msg);
                return cb();
            }
            cb(null, msg);
        },
    }), duplex.in, socketClosed.bind(null, duplex));
    stream_1.pipeline(duplex.out, new stream_1.Transform({
        objectMode: true,
        transform(obj, encoding, cb) {
            if (!process.env.LATENCY)
                cb(null, obj);
            else
                setTimeout(() => cb(null, obj), Number.parseInt(process.env.LATENCY));
        },
    }), new stream_1.Transform({
        writableObjectMode: true,
        readableObjectMode: false,
        transform(obj, encoding, cb) {
            const msg = toTelepathyMsg(JSON.stringify(obj));
            cb(null, msg);
        },
    }), socket, socketClosed.bind(null, duplex));
    sendTo(duplex, [Codes.hello]);
    waitingQueue.push(duplex);
    tryStartMatch();
});
function safeWaitForHello(socket) {
    const BYTES_TO_READ = 8; // Codes.hello: 0004[11]
    return new Promise((resolve, reject) => {
        socket.on('readable', () => {
            if (socket.readableLength < BYTES_TO_READ)
                return;
            const data = socket.read(BYTES_TO_READ).toString();
            let code;
            try {
                ;
                [code] = JSON.parse(data.slice(4));
            }
            catch (err) {
                return reject(err + `\ndata=${data}`);
            }
            if (code !== Codes.hello)
                return reject('weird data: ' + data);
            socket.removeAllListeners();
            resolve();
        });
        socket.on('close', endSocket);
        socket.on('error', endSocket);
        function endSocket(err) {
            socket.removeAllListeners();
            reject(err);
        }
    });
}
let waitingForPlayersTimeout;
function tryStartMatch(timeout) {
    clearBadSockets();
    if ((!timeout && waitingQueue.length < 4) || (timeout && waitingQueue.length < 2)) {
        if (!waitingForPlayersTimeout || timeout) {
            if (waitingQueue.length === 0) {
                waitingForPlayersTimeout = undefined;
                return;
            }
            console.info('not enough players. waiting');
            const waitTime = process.env.LOBBY_WAIT_TIME ? Number.parseInt(process.env.LOBBY_WAIT_TIME) : 60000;
            waitingForPlayersTimeout = setTimeout(tryStartMatch.bind(null, true), waitTime);
        }
        return;
    }
    if (waitingForPlayersTimeout)
        clearTimeout(waitingForPlayersTimeout);
    waitingForPlayersTimeout = undefined;
    new Match(waitingQueue).Start();
    waitingQueue = [];
}
function onGuessTime(player, msg) {
    const playerGuess = msg[1];
    const offset = Date.now() - playerGuess;
    sendTo(player, [Codes.guessTime, offset]);
}
function socketClosed(player, err) {
    if (player.inactive)
        return;
    if (err) {
        console.info({ err });
        if (!player.socket.destroyed)
            player.socket.destroy();
    }
    clearBadSockets();
}
function clearBadSockets() {
    waitingQueue = waitingQueue.filter((it) => {
        const isGood = !it.socket.destroyed && it.socket.readable && it.socket.writable;
        if (isGood)
            return true;
        it.in.destroy();
        it.out.destroy();
        return false;
    });
}
const PORT = process.env.PORT ? Number.parseInt(process.env.PORT) : 7777;
server.on('listening', () => {
    console.info(`listening on port ${PORT}`);
});
server.on('error', (err) => {
    console.info('server error:', err);
});
server.listen(PORT);
class Match {
    constructor(players) {
        this.matchEnded = false;
        this.onIntroduce = (player, msg) => {
            const [code, playerNumber, playerName, fbId] = msg;
            if (fbId)
                this.players[player].fbId = fbId;
        };
        this.resendToOthers = (player, msg) => {
            this.players
                .filter((_, index) => index !== player)
                .forEach((other) => {
                sendTo(other, msg);
            });
        };
        this.logReceived = (player, msg) => {
            console.info({ player, msg });
        };
        this.StopPlayer = (playerNumber, err) => {
            const player = this.players[playerNumber];
            if (err) {
                console.info(err);
                player.in.destroy();
                player.out.destroy();
            }
            player.inactive = true;
            if (this.matchEnded)
                return;
            // todo: send to others that player disconnected perhaps?
            this.votersCentral.PunishPlayer(playerNumber);
            const playersPlaying = this.playersPlayingNumber();
            if (playersPlaying < 2)
                this.TryEndMatch();
        };
        this.TryEndMatch = async () => {
            const playersPlaying = this.playersPlayingNumber();
            const isThereAWinner = this.votersCentral.isThereAWinner();
            if (playersPlaying >= 2 && !isThereAWinner) {
                this.matchTimer = setTimeout(() => this.TryEndMatch(), 10000);
                return;
            }
            if (this.matchTimer) {
                clearTimeout(this.matchTimer);
                this.matchTimer = undefined;
            }
            this.matchEnded = true;
            this.votersCentral.Stop();
            this.resendToOthers(-1, [Codes.matchOver]);
            const newScores = await this.CalcEloScores();
            const scoresToSave = newScores
                .filter((it) => this.players[it.playerNumber].fbId)
                .map((it) => ({ fb_id: this.players[it.playerNumber].fbId, score: it.newScore }));
            await this.savePlayersScores(scoresToSave);
            const matchResult = newScores
                .slice()
                .sort((a, b) => a.playerNumber - b.playerNumber)
                .map((it) => [it.votes, it.newScore, it.scoreDiff]);
            const msg = [Codes.newScores, ...matchResult];
            this.players.forEach((it) => {
                it.out.end(msg);
            });
            --matchesRunning;
            console.info({ matchesRunning });
        };
        this.players = players = lodash.shuffle(players);
        this.votersCentral = new VotersCentral(players);
    }
    Start() {
        const codesMap = {
            [Codes.newPlayerDestination]: this.resendToOthers,
            [Codes.projectileFired]: (player, msg) => {
                this.resendToOthers(player, msg);
                this.votersCentral.ProjectileFired(player, msg);
            },
            [Codes.tryConvertVoter]: this.votersCentral.TryConvertVoter,
            [Codes.tryClaimVoter]: this.votersCentral.TryClaimVoter,
            [Codes.tryAddVotes]: this.votersCentral.TryAddVotes,
            [Codes.log]: this.logReceived,
            [Codes.newAlly]: this.resendToOthers,
            [Codes.destroyProjectile]: this.resendToOthers,
            [Codes.introduce]: (player, msg) => {
                this.onIntroduce(player, msg);
                this.resendToOthers(player, msg);
            },
        };
        this.players.forEach((player, index) => {
            const stopPlayer = this.StopPlayer.bind(this, index);
            player.in.on('end', stopPlayer);
            player.in.on('close', stopPlayer);
            player.in.on('error', stopPlayer);
            player.in.on('data', (msg) => {
                const code = msg[0];
                if (!(code in codesMap)) {
                    console.info('unmapped code', code);
                    return;
                }
                codesMap[code](index, msg);
            });
        });
        this.players.forEach((player, index) => {
            sendTo(player, [Codes.start, index, this.players.length]);
        });
        this.votersCentral.Start();
        this.matchTimer = setTimeout(this.TryEndMatch, MATCH_TIME);
        ++matchesRunning;
        console.info({ matchesRunning });
    }
    playersPlayingNumber() {
        return this.players.reduce((accum, next) => accum + (next.inactive ? 0 : 1), 0);
    }
    getPlayersScores() {
        return Promise.all(this.players.map(async (p) => {
            if (!p.fbId)
                return Elo_1.initialScore;
            const score = await ScoresRepo.getScore(p.fbId);
            if (!score)
                return Elo_1.initialScore;
            return score.score;
        }));
    }
    savePlayersScores(scores) {
        return Promise.all(scores.map((it) => {
            if (!it.fb_id)
                return;
            const score = { fb_id: it.fb_id, score: it.score };
            return ScoresRepo.putScore(score);
        }));
    }
    async CalcEloScores() {
        const results = this.votersCentral.getVotesResults();
        const playerPrevScores = await this.getPlayersScores();
        const eloInputs = this.players.map((_, index) => ({
            id: index,
            prevScore: playerPrevScores[index],
            result: results[index],
        }));
        const newScores = Elo_1.multiElo(eloInputs);
        return newScores.map((it) => ({
            ...it,
            playerNumber: it.id,
            votes: results[it.id],
            scoreDiff: it.newScore - playerPrevScores[it.id],
        }));
    }
}
class VotersCentral {
    constructor(players) {
        this.players = players;
        this.matchEnded = false;
        this.voterSeq = 0;
        this.voters = [];
        this.PeriodicTasks = () => {
            if (this.matchEnded)
                return this.Stop();
            this.SendVotersPack();
            this.SendVotersToCentrals();
        };
        this.SendVotersPack = () => {
            const votesPerSecond = Math.ceil(this.players.length / 2);
            const votersToSend = lodash.times(votesPerSecond).map(GenerateVoterPositionX).map(this.GenerateVoterCloseTo);
            this.SendVotersToAll(votersToSend);
        };
        this.SendVotersToCentrals = () => {
            this.centralBases.forEach((positionX, player) => {
                if (positionX === undefined)
                    return;
                if (Math.random() < 0.7)
                    return;
                var voter = this.GenerateVoterCloseTo(positionX);
                this.SendVoterConverted(player, voter);
            });
        };
        this.TryConvertVoter = (player, msg) => {
            const NO_PLAYER = -1;
            const [code, voterId, playerToConvertTo, time] = msg;
            const voter = this.voters[voterId];
            if (voter.claimed)
                return;
            if (playerToConvertTo !== NO_PLAYER && voter.lastHitTime > time)
                return;
            voter.player = playerToConvertTo;
            voter.lastHitTime = time;
            const reply = [Codes.voterConverted, voterId, playerToConvertTo];
            this.players.forEach((it) => {
                sendTo(it, reply);
            });
        };
        this.TryClaimVoter = (player, msg) => {
            const [code, voterId] = msg;
            const voter = this.voters[voterId];
            if (voter.claimed)
                return;
            if (voter.player !== player)
                return;
            voter.player = player;
            voter.claimed = true;
            ++this.votesCounts[player];
            const reply = [Codes.voterClaimed, voterId, player];
            this.players.forEach((it) => {
                sendTo(it, reply);
            });
        };
        this.TryAddVotes = (player, msg) => {
            const [code, playerNumberToAddVotes, votes] = msg;
            this.votesCounts[playerNumberToAddVotes] += votes;
            const reply = [Codes.votesAdded, playerNumberToAddVotes, votes];
            this.players.forEach((it) => {
                sendTo(it, reply);
            });
        };
        this.ProjectileFired = (player, msg) => {
            const CENTRAL_BASE_PROJECTILE_TYPES = [4, 5, 6];
            const ABSTENTION_PROJECTILE_TYPE = 13;
            const [code, playerOwner, destination, timeWhenReach, projectileType, targetPlayer, projectileId] = msg;
            const [projectilePositionX, projectilePositionY] = destination;
            if (CENTRAL_BASE_PROJECTILE_TYPES.includes(projectileType)) {
                this.centralBases[playerOwner] = projectilePositionX;
                lodash
                    .times(3)
                    .fill(projectilePositionX)
                    .map(this.GenerateVoterCloseTo)
                    .forEach(this.SendVoterConverted.bind(null, playerOwner));
                return;
            }
            if (projectileType === ABSTENTION_PROJECTILE_TYPE) {
                const generateVoters = () => {
                    if (this.matchEnded)
                        return;
                    this.SendVotersToAll(lodash.times(5).fill(projectilePositionX).map(this.GenerateVoterCloseTo));
                };
                generateVoters();
                generateVoters();
                setTimeout(generateVoters, 1000);
                setTimeout(generateVoters, 2000);
            }
        };
        this.SendVoterConverted = (playerOwner, voter) => {
            this.SendVotersToAll([voter]);
            this.TryConvertVoter(playerOwner, [Codes.tryConvertVoter, voter[0], playerOwner, Date.now()]);
        };
        this.GenerateVoterCloseTo = (x) => {
            let positionX = x + (Math.random() * 20.0 - 10.0);
            positionX = Math.min(positionX, MAP_WIDTH / 2);
            positionX = Math.max(positionX, MAP_WIDTH / -2);
            const voter = { positionX, lastHitTime: 0, player: -1, claimed: false };
            this.voters.push(voter);
            return [this.voterSeq++, positionX];
        };
        this.votesCounts = Array(players.length).fill(0);
        this.centralBases = Array(players.length).fill(undefined);
    }
    Start() {
        this.myInterval = setInterval(this.PeriodicTasks, 1000);
    }
    Stop() {
        this.matchEnded = true;
        if (this.myInterval)
            clearInterval(this.myInterval);
        this.myInterval = undefined;
    }
    SendVotersToAll(votersToSend) {
        const msg = [Codes.newVoters, ...votersToSend];
        this.players.forEach((player) => {
            sendTo(player, msg);
        });
    }
    PunishPlayer(playerNumber) {
        this.votesCounts[playerNumber] = 0;
    }
    isThereAWinner() {
        const sortedVotes = this.votesCounts.slice().sort((a, b) => b - a);
        return sortedVotes[0] > sortedVotes[1];
    }
    getVotesResults() {
        return Object.fromEntries(this.votesCounts.map((votes, index) => [index, votes]));
    }
}
function GenerateVoterPositionX() {
    const forVoterRegion = Math.random();
    const forVoterPosition = Math.random();
    let voterPosition;
    if (forVoterRegion < 0.26) {
        voterPosition = forVoterPosition * 0.18 + 0;
    }
    else if (forVoterRegion < 0.38) {
        voterPosition = forVoterPosition * 0.13 + 0.18;
    }
    else if (forVoterRegion < 0.78) {
        voterPosition = forVoterPosition * 0.3 + 0.31;
    }
    else if (forVoterRegion < 0.9) {
        voterPosition = forVoterPosition * 0.24 + 0.61;
    }
    else {
        voterPosition = forVoterPosition * 0.15 + 0.85;
    }
    return (voterPosition - 0.5) * MAP_WIDTH;
}
function sendTo(duplex, msg) {
    if (duplex.inactive)
        return;
    if (duplex.out.destroyed || !duplex.out.writable) {
        console.info('unable to send msg', msg);
        return;
    }
    duplex.out.write(msg);
}
class TelepathyInputTransformer extends stream_1.Transform {
    constructor() {
        super({ writableObjectMode: false, readableObjectMode: true });
        this.msgSize = undefined;
        this.buffer = Buffer.from('');
    }
    _transform(chunk, encoding, cb) {
        this.buffer = Buffer.concat([this.buffer, chunk], this.buffer.length + chunk.length);
        while (true) {
            if (!this.msgSize) {
                if (this.buffer.length < 4)
                    break;
                const msg = this.buffer.slice(0, 4);
                this.buffer = this.buffer.slice(4);
                this.msgSize = msg[0] * 256 ** 3 + msg[1] * 256 ** 2 + msg[2] * 256 ** 1 + msg[3] * 256 ** 0;
            }
            if (this.buffer.length < this.msgSize)
                break;
            const msg = this.buffer.slice(0, this.msgSize);
            this.buffer = this.buffer.slice(this.msgSize);
            this.push(msg);
            this.msgSize = undefined;
        }
        cb();
    }
}
function toTelepathyMsg(data) {
    const dataLength = data.length;
    const encodedData = Buffer.from(`0000${data}`, 'ascii');
    encodedData[0] = (dataLength & 0xff000000) >> 24;
    encodedData[1] = (dataLength & 0xff0000) >> 16;
    encodedData[2] = (dataLength & 0xff00) >> 8;
    encodedData[3] = (dataLength & 0xff) >> 0;
    return encodedData;
}
