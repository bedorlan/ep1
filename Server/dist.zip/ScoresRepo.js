"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const AWS = require("aws-sdk");
const awsConf = { region: 'us-east-1' };
const dynamoConf = {};
if (process.env.DYNAMO_ENDPOINT) {
    Object.assign(dynamoConf, { endpoint: process.env.DYNAMO_ENDPOINT });
}
else {
    Object.assign(awsConf, {
        accessKeyId: 'AKIAVQP6QK3UBHX5JVJ5',
        secretAccessKey: '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',
    });
}
AWS.config.update(awsConf);
const db = new AWS.DynamoDB(dynamoConf);
const TableName = 'scores';
function putScore(item) {
    const Item = { fb_id: { S: item.fb_id }, score: { N: item.score.toString() } };
    return new Promise((resolve, reject) => {
        db.putItem({ TableName, Item }, (err) => {
            if (err)
                return reject(err);
            resolve();
        });
    });
}
exports.putScore = putScore;
function getScore(fb_id) {
    const Key = { fb_id: { S: fb_id } };
    return new Promise((resolve, reject) => {
        db.getItem({ TableName, Key }, (err, data) => {
            if (err)
                return reject(err);
            if (!data || !data.Item)
                return resolve(null);
            const Item = { fb_id: data.Item.fb_id.S, score: Number.parseInt(data.Item.score.N) };
            resolve(Item);
        });
    });
}
exports.getScore = getScore;
