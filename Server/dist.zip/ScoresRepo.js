"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const AWS = require("aws-sdk");
const awsConf = { region: 'us-east-1' };
const dynamoConf = {};
if (process.env.DYNAMO_ENDPOINT) {
    Object.assign(dynamoConf, { endpoint: process.env.DYNAMO_ENDPOINT });
}
else {
    Object.assign(awsConf, {
        accessKeyId: 'AKIAVQP6QK3UBHX5JVJ5',
        secretAccessKey: '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',
    });
}
AWS.config.update(awsConf);
const db = new AWS.DynamoDB(dynamoConf);
const TableName = 'scores';
function putScore(item) {
    const Item = {
        fb_id: { S: item.fb_id },
        score: { N: item.score.toString() },
        active: { N: '1' },
    };
    return new Promise((resolve, reject) => {
        db.putItem({ TableName, Item }, (err) => {
            if (err)
                return reject(err);
            resolve();
        });
    });
}
exports.putScore = putScore;
function getScore(fb_id) {
    const Key = { fb_id: { S: fb_id } };
    return new Promise((resolve, reject) => {
        db.getItem({ TableName, Key }, (err, data) => {
            if (err)
                return reject(err);
            if (!data || !data.Item)
                return resolve(null);
            resolve(itemToScore(data.Item));
        });
    });
}
exports.getScore = getScore;
function batchGetScore(fb_ids) {
    const Keys = fb_ids.map((it) => ({ fb_id: { S: it } }));
    return new Promise((resolve, reject) => {
        db.batchGetItem({ RequestItems: { [TableName]: { Keys } } }, (err, data) => {
            var _a;
            if (err)
                return reject(err);
            if (!((_a = data === null || data === void 0 ? void 0 : data.Responses) === null || _a === void 0 ? void 0 : _a.scores))
                return resolve([]);
            const scores = data.Responses.scores.map(itemToScore);
            resolve(scores);
        });
    });
}
exports.batchGetScore = batchGetScore;
function getTop3() {
    return new Promise((resolve, reject) => {
        db.query({
            TableName,
            IndexName: 'active-score-index',
            ScanIndexForward: false,
            KeyConditions: {
                active: { ComparisonOperator: 'EQ', AttributeValueList: [{ N: '1' }] },
            },
            Limit: 3,
        }, (err, data) => {
            var _a, _b;
            if (err)
                return reject(err);
            resolve((_b = (_a = data.Items) === null || _a === void 0 ? void 0 : _a.map(itemToScore)) !== null && _b !== void 0 ? _b : []);
        });
    });
}
exports.getTop3 = getTop3;
function itemToScore(Item) {
    return { fb_id: Item.fb_id.S, score: Number.parseInt(Item.score.N) };
}
