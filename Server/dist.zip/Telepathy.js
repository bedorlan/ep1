"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const stream_1 = require("stream");
class TelepathyInputTransformer extends stream_1.Transform {
    constructor() {
        super({ writableObjectMode: false, readableObjectMode: true });
        this.msgSize = undefined;
        this.buffer = Buffer.from('');
    }
    _transform(chunk, encoding, cb) {
        this.buffer = Buffer.concat([this.buffer, chunk], this.buffer.length + chunk.length);
        while (true) {
            if (!this.msgSize) {
                if (this.buffer.length < 4)
                    break;
                const msg = this.buffer.slice(0, 4);
                this.buffer = this.buffer.slice(4);
                this.msgSize = msg[0] * 256 ** 3 + msg[1] * 256 ** 2 + msg[2] * 256 ** 1 + msg[3] * 256 ** 0;
            }
            if (this.buffer.length < this.msgSize)
                break;
            const msg = this.buffer.slice(0, this.msgSize);
            this.buffer = this.buffer.slice(this.msgSize);
            this.push(msg);
            this.msgSize = undefined;
        }
        cb();
    }
}
exports.TelepathyInputTransformer = TelepathyInputTransformer;
function toTelepathyMsg(data) {
    const dataLength = data.length;
    const encodedData = Buffer.from(`0000${data}`, 'ascii');
    encodedData[0] = (dataLength & 0xff000000) >> 24;
    encodedData[1] = (dataLength & 0xff0000) >> 16;
    encodedData[2] = (dataLength & 0xff00) >> 8;
    encodedData[3] = (dataLength & 0xff) >> 0;
    return encodedData;
}
exports.toTelepathyMsg = toTelepathyMsg;
